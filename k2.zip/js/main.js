
$(document).ready(function()
{
    $('select').materialSelect();
    //new WOW().init();

})
