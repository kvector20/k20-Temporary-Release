<?php

if(isset($_POST['send']))
{   
    echo $_POST['name'];
    echo $_POST['mail'];
    echo $_POST['phone'];
    $first;
    $second;

    foreach($_POST['first'] as $f)
    {
        $first = $f;
    }
    foreach($_POST['second'] as $s)
    {
        $second = $s;
    }
    echo $first;
    echo $second;

}

?>